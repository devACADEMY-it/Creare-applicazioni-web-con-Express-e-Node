const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const User = require('../models/User');

router.get('/login', (req, res) => {
  res.render('login');
});

router.get('/register', (req, res) => {
  res.render('register');
});

router.post('/register', async (req, res) => {
  const { username, email, password, confirmPassword } = req.body;
  let errors = [];

  if (!username || !email || !password || !confirmPassword) {
    errors.push({ message: "Devi riempire tutti i campi" });
  }

  if (password !== confirmPassword) {
    errors.push({ message: "Le due password devono coincidere" });
  }

  if (password.length < 8) {
    errors.push({ message: "La password deve essere lunga almeno 8 caratteri" })
  }

  if (errors.length > 0) {
    res.render('register', { errors });
  } else {
    const user = await User.findOne({ email: email });
    if (user) {
      errors.push({ message: "Email già registrata" });
      res.render('register', { errors });
    } else {
      try {
        const salt = await bcrypt.genSalt();
        const hashedPassword = await bcrypt.hash(password, salt);

        const newUser = new User({
          username,
          email,
          password: hashedPassword
        });
        await newUser.save();
        res.redirect('/login');
      } catch(error) {
        errors.push({ message: "Qualcosa è andato storto. Riprovare." });
        res.render('register', { errors });
      }
    }
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  let errors = [];

  if (!email || !password) {
    errors.push({ message: "Devi riempire tutti i campi" });
  }

  if (errors.length > 0) {
    res.render('login', { errors });
  } else {
    const user = await User.findOne({ email: email });

    if (user) {
      try {
        const comparePassword = await bcrypt.compare(password, user.password);
        if (comparePassword) {
          // Login success
          req.session.isLoggedIn = true;
          req.session.email = email;
          res.redirect('/posts');
        } else {
          errors.push({ message: "La password non è corretta." });
          res.render('login', { errors });
        }
      } catch(error) {
        errors.push({ message: "Qualcosa è andato storto. Riprovare." });
        res.render('login', { errors });
      }
    } else {
      errors.push({ message: "L'email non è stata trovata." });
      res.render('login', { errors });
    }
  }
});

router.get('/logout', function(req, res) {
  req.session.isLoggedIn = false;
  req.session.email = null;
  res.redirect('/login');
});

module.exports = router;
