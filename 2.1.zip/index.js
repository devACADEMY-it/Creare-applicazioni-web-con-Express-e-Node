const express = require('express');

const app = express();

const PORT = process.env.port || 5000;

app.get('/', function(req, res) {
  res.send('<h1>Homepage</h1>');
});

app.listen(PORT, () => {
  console.log("Server listening on port 5000");
});
