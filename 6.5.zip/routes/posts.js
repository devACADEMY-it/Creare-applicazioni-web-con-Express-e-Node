const express = require('express');
const router = express.Router();
const Post = require('../models/Post');

// Tutti i post
router.get('/', async (req, res) => {
  try {
    const posts = await Post.find();
    // res.json(posts);
    res.render('index', { posts });
  } catch(error) {
    res.json({ message: error });
  }
});

// Pagina di creazione del post
router.get('/create', async (req, res) => {
  try {
    res.render('create');
  } catch(error) {
    res.json({ message: error });
  }
});

// Pagina di modifica del post
router.get('/:postId/edit', async (req, res) => {
  try {
    const post = await Post.findById(req.params.postId);
    res.render('edit', { post });
  } catch(error) {
    res.json({ message: error });
  }
});

// Dettaglio del post
router.get('/:postId', async (req, res) => {
  try {
    const post = await Post.findById(req.params.postId);
    // res.json(post);
    res.render('post-detail', { post });
  } catch(error) {
    res.json({ message: error });
  }
});

// Creazione del post
router.post('/', async (req, res) => {
  const { title, author, content, excerpt, category } = req.body;
  const post = new Post({
    title,
    author,
    excerpt,
    content,
    category
  });

  try {
    const newPost = await post.save();
    res.redirect('/posts');
  } catch(error) {
    res.json({ message: error });
  }
});

// Modifica del post
router.post('/:postId/edit', async (req, res) => {
  try {
    const patchedPost = await Post.updateOne({ _id: req.params.postId }, {
      $set: {
        title: req.body.title,
        category: req.body.category,
        excerpt: req.body.excerpt,
        content: req.body.content
      }
    });
    res.json(patchedPost);
  } catch(error) {
    res.json({ message: error });
  }
});

// Cancellazione del post
router.delete('/:postId', async (req, res) => {
  try {
    const removedPost = await Post.remove({ _id: req.params.postId });
    res.json(removedPost);
  } catch(error) {
    res.json({ message: error });
  }
});

module.exports = router;
