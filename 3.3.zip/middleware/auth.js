const admins = [
  'carmhack',
  'adriano',
  'giovanni',
  'alberto'
];

const auth = (req, res, next) => {
  const { user } = req.query;
  const isAdmin = admins.find((admin) => admin === user);

  if (isAdmin) {
    next();
  } else {
    res.send('<h1>Non hai accesso a questa pagina.</h1>');
  }
};

module.exports = auth;
