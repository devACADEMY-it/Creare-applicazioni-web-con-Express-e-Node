const error = (err, req, res, next) => {
  console.log(err);
};

module.exports = error;
