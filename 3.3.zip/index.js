const express = require('express');
const simpsonRoutes = require('./routes/api/simpson');
const pagesRoutes = require('./routes/pages');

const logger = require('./middleware/logger');
const error = require('./middleware/error');

const app = express();
const PORT = process.env.port || 5000;

app.use(error);
app.use(logger);

app.use('/api/simpson', simpsonRoutes);
app.use('/', pagesRoutes);

app.listen(PORT, () => {
  console.log("Server listening on port 5000");
});
