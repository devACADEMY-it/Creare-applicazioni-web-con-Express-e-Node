const express = require('express');
const router = express.Router();
const Post = require('../models/Post');

router.get('/', async (req, res) => {
  try {
    const posts = await Post.find();
    res.json(posts);
  } catch(error) {
    res.json({ message: error });
  }
});

router.get('/:postId', async (req, res) => {
  try {
    const posts = await Post.findById(req.params.postId);
    res.json(posts);
  } catch(error) {
    res.json({ message: error });
  }
});

router.post('/', async (req, res) => {
  const { title, author, content } = req.body;
  const post = new Post({
    title,
    author,
    content
  });

  try {
    const newPost = await post.save();
    res.json(newPost);
  } catch(error) {
    res.json({ message: error });
  }
});

router.patch('/:postId', async (req, res) => {
  try {
    const patchedPost = await Post.updateOne({ _id: req.params.postId }, {
      $set: {
        title: req.body.title,
        category: req.body.category
      }
    });
    res.json(patchedPost);
  } catch(error) {
    res.json({ message: error });
  }
});

router.delete('/:postId', async (req, res) => {
  try {
    const removedPost = await Post.remove({ _id: req.params.postId });
    res.json(removedPost);
  } catch(error) {
    res.json({ message: error });
  }
});

module.exports = router;
