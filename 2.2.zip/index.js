const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.port || 5000;

app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/about', function(req, res) {
  res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

// app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
  console.log("Server listening on port 5000");
});
