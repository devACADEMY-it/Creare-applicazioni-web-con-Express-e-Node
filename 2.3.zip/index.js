const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.port || 5000;

const items = [
  {
    id: 1,
    name: "Homer Simpson",
    image: "https://cdn.glitch.com/3c3ffadc-3406-4440-bb95-d40ec8fcde72%2FHomerSimpson.png?1497567511939"
  },
  {
    id: 2,
    name: "Duffman",
    image: "https://cdn.glitch.com/3c3ffadc-3406-4440-bb95-d40ec8fcde72%2FDuffman.png?1497567511709"
  },
  {
    id: 3,
    name: "Bart Simpson",
    image: "https://cdn.glitch.com/3c3ffadc-3406-4440-bb95-d40ec8fcde72%2FBartSimpson.png?1497567511638"
  },
  {
    id: 4,
    name: "Ralph Wincester",
    image: "https://cdn.glitch.com/3c3ffadc-3406-4440-bb95-d40ec8fcde72%2FRalphWiggum.png?1497567511523"
  }
];

// Tutti i personaggi dei Simpson
app.get('/api/simpson', (req, res) => {
  res.json(items);
});

// Singolo personaggio dei Simpson
app.get('/api/simpson/:id', (req, res) => {
  const findItem = items.find(item => item.id === parseInt(req.params.id));
  res.json(findItem);
});

app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/about', function(req, res) {
  res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

// app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
  console.log("Server listening on port 5000");
});
