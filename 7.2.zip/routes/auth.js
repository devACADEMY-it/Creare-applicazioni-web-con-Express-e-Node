const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.get('/login', (req, res) => {
  res.render('login');
});

router.get('/register', (req, res) => {
  res.render('register');
});

router.post('/register', async (req, res) => {
  const { username, email, password, confirmPassword } = req.body;
  let errors = [];

  if (!username || !email || !password || !confirmPassword) {
    errors.push({ message: "Devi riempire tutti i campi" });
  }

  if (password !== confirmPassword) {
    errors.push({ message: "Le due password devono coincidere" });
  }

  if (password.length < 8) {
    errors.push({ message: "La password deve essere lunga almeno 8 caratteri" })
  }

  if (errors.length > 0) {
    res.render('register', { errors });
  } else {
    const user = await User.findOne({ email: email });
    if (user) {
      errors.push({ message: "Email già registrata" });
      res.render('register', { errors });
    } else {
      const newUser = new User({
        username,
        email,
        password
      });
      await newUser.save();
      res.redirect('/login');
    }
  }
});

module.exports = router;
