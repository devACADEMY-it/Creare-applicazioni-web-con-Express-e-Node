const mongoose = require('mongoose');

const PostSchema = mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  author: {
    type: String,
    required: true
  },
  content: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    required: false,
    default: Date.now(),
  },
  category: {
    type: String,
    required: false,
    default: "Generics"
  }
});

module.exports = mongoose.model('Posts', PostSchema);
