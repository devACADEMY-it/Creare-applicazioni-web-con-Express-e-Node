const express = require('express');
const router = express.Router();
const Post = require('../models/Post');

router.get('/', (req, res) => {
  res.send('Home dei post');
});

router.post('/', async (req, res) => {
  const { title, author, content } = req.body;
  const post = new Post({
    title,
    author,
    content
  });

  try {
    const newPost = await post.save();
    res.json(newPost);
  } catch(error) {
    res.json({ message: error });
  }
});

module.exports = router;
