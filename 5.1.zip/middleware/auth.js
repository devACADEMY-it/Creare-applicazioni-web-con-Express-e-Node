function auth(req, res, next) {
  const { admin, password } = req.query;
  if (admin === 'carmhack' && password === '123') {
    next();
  } else {
    res.send('<h1>Non hai accesso a questa pagina</h1>');
  }
}

module.exports = auth;
