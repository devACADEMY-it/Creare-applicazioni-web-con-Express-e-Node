require('dotenv/config');
const express = require('express');
const path = require('path');
const cors = require('cors');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const postsRouter = require('./routes/posts');

const PORT = process.env.PORT || 5000;

const app = express();

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(cors());
app.use(bodyParser.json());
app.use('/posts', postsRouter);

app.listen(PORT, () => {
  console.log("Server listening on port 5000");
});

mongoose.connect(process.env.DB_CONNECTION,
{ useNewUrlParser: true, useUnifiedTopology: true },
() => {
  console.log('Connessi al db');
});
