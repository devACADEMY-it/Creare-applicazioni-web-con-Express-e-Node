const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const logger = require('./middleware/logger');
const auth = require('./middleware/auth');
const error = require('./middleware/error');

const app = express();
const PORT = process.env.port || 5000;

mongoose.connect('mongodb+srv://admin:lolrotfl@cluster0.qeunb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', () => {
  console.log('Connessi al db');
});

app.use(logger);
app.use(error);

// Endpoint SIMPSONS
app.use('/api/simpsons', require('./routes/api/simpsons'));

// Pagine
app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
app.get('/about', function(req, res) {
  res.sendFile(path.join(__dirname, 'public', 'about.html'));
});
app.get('/secret', auth, function(req, res) {
  res.send('<h1>Password: abc123</h1>');
});

app.listen(PORT, () => {
  console.log("Server listening on port 5000");
});
