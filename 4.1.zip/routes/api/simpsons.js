const express = require('express');
const router = express.Router();

// Data
const items = [
  {
    id: 1,
    name: "Homer Simpson",
    image: "https://cdn.glitch.com/3c3ffadc-3406-4440-bb95-d40ec8fcde72%2FHomerSimpson.png?1497567511939"
  },
  {
    id: 2,
    name: "Duffman",
    image: "https://cdn.glitch.com/3c3ffadc-3406-4440-bb95-d40ec8fcde72%2FDuffman.png?1497567511709"
  },
  {
    id: 3,
    name: "Bart Simpson",
    image: "https://cdn.glitch.com/3c3ffadc-3406-4440-bb95-d40ec8fcde72%2FBartSimpson.png?1497567511638"
  },
  {
    id: 4,
    name: "Ralph Wincester",
    image: "https://cdn.glitch.com/3c3ffadc-3406-4440-bb95-d40ec8fcde72%2FRalphWiggum.png?1497567511523"
  }
];

// Tutti i personaggi dei Simpson
router.get('/', (req, res) => {
  res.json(items);
});

// Singolo personaggio dei Simpson
router.get('/:id', (req, res) => {
  const findItem = items.find(item => item.id === parseInt(req.params.id));

  if (findItem) {
    res.json(items.filter(item => item.id === parseInt(req.params.id)));
  } else {
    res.status(404).json({ status: 404, error: 'Personaggio non trovato' });
  }
});

module.exports = router;
